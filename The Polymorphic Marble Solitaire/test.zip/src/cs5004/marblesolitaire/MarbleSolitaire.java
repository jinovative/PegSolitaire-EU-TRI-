package cs5004.marblesolitaire;

public final class MarbleSolitaire {
  public static void main(String[] args) {

  }
}
